//
//  ModalViewController.h
//  MinatoAndrea
//
//  Created by AndreaITS on 02/03/17.
//  Copyright © 2017 AndreaITS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController


@end
